-- CreateTable
CREATE TABLE "Usuario" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "nombre" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "rol" TEXT NOT NULL DEFAULT 'LIDER',
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "llamadasPerdidas" INTEGER NOT NULL DEFAULT 0,
    "puntosAcumulados" INTEGER NOT NULL DEFAULT 0,
    "vision" TEXT,
    "sede" TEXT,
    "mentorId" INTEGER,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "CartaFrutos" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "finanzasMeta" TEXT,
    "finanzasAvance" INTEGER NOT NULL DEFAULT 0,
    "relacionesMeta" TEXT,
    "relacionesAvance" INTEGER NOT NULL DEFAULT 0,
    "talentosMeta" TEXT,
    "talentosAvance" INTEGER NOT NULL DEFAULT 0,
    "pazMentalMeta" TEXT,
    "pazMentalAvance" INTEGER NOT NULL DEFAULT 0,
    "ocioMeta" TEXT,
    "ocioAvance" INTEGER NOT NULL DEFAULT 0,
    "saludMeta" TEXT,
    "saludAvance" INTEGER NOT NULL DEFAULT 0,
    "servicioTransMeta" TEXT,
    "servicioTransAvance" INTEGER NOT NULL DEFAULT 0,
    "servicioComunMeta" TEXT,
    "servicioComunAvance" INTEGER NOT NULL DEFAULT 0,
    "enrolamientoMeta" TEXT DEFAULT 'Invitar a 4 personas',
    "invitadosInscritos" INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT "CartaFrutos_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "Usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Evidencia" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "categoria" TEXT NOT NULL,
    "urlFoto" TEXT NOT NULL,
    "fechaSubida" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Evidencia_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "Usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "Usuario_email_key" ON "Usuario"("email");

-- CreateIndex
CREATE UNIQUE INDEX "CartaFrutos_usuarioId_key" ON "CartaFrutos"("usuarioId");
