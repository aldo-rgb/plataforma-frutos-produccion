// app/api/evidencia/completar/route.ts
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(req: Request) {
  // 1. Obtener la sesión del usuario (SIMULADO)
  const userId = 1; // **IMPORTANTE: En la vida real, obtendrías esto de la sesión/token**

  try {
    // CAMBIO: Leemos el cuerpo como JSON, no como FormData
    const body = await req.json();
    console.log('📥 Body recibido:', body); // Debug
    
    const { categoria, taskId } = body;
    const taskIdInt = parseInt(taskId);
    
    console.log('📊 Datos parseados:', { categoria, taskId, taskIdInt }); // Debug

    if (!taskIdInt || !categoria) {
      console.error('❌ Faltan datos:', { taskIdInt, categoria });
      return NextResponse.json({ error: 'Faltan datos de la tarea.' }, { status: 400 });
    }

    // SIMULACIÓN: Asumimos que la foto se subió, generamos una URL estática
    const urlSimulada = `https://evidencia.impactocuantico.com/${categoria}_${taskIdInt}_${Date.now()}.jpg`;
    
    console.log('📸 URL generada:', urlSimulada); // Debug

    // 2. CREAR REGISTRO DE EVIDENCIA
    const nuevaEvidencia = await prisma.evidencia.create({
      data: {
        usuarioId: userId,
        categoria: categoria,
        urlFoto: urlSimulada,
      },
    });
    
    console.log('✅ Evidencia creada:', nuevaEvidencia); // Debug

    // 3. NOTA IMPORTANTE: 
    // Por ahora las tareas son solo UI local (no están en BD aún).
    // El taskId que llega es un ID local (1 o 2) que no corresponde a ninguna fila en la tabla Tarea.
    // Cuando implementes el sistema completo de tareas con BD:
    // 1. Crea las tareas reales cuando el usuario define metas en /api/carta
    // 2. Aquí vincula la evidencia: await prisma.tarea.update({ where: { id: taskIdInt }, data: { completada: true, evidenciaId: nuevaEvidencia.id }});
    
    return NextResponse.json({ 
        message: 'Evidencia guardada exitosamente.',
        evidencia: nuevaEvidencia,
    });

  } catch (error) {
    console.error('Error en API Evidencia:', error);
    const errorMessage = error instanceof Error ? error.message : 'Error desconocido';
    return NextResponse.json({ 
      error: 'Fallo al completar la tarea.', 
      details: errorMessage 
    }, { status: 500 });
  }
}