import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    // TODO: Obtener el ID del usuario autenticado desde la sesión/token
    // Por ahora, asumimos el primer usuario como ejemplo
    // En producción, esto debe venir de tu sistema de autenticación
    
    const usuario = await prisma.usuario.findFirst({
      select: {
        rol: true,
        nombre: true,
        email: true,
        vision: true
      }
    });

    if (!usuario) {
      return NextResponse.json(
        { error: 'Usuario no encontrado' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      rol: usuario.rol,
      nombre: usuario.nombre,
      email: usuario.email,
      vision: usuario.vision
    });

  } catch (error) {
    console.error('Error al obtener perfil del usuario:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
