import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

// 1. OBTENER DATOS (GET)
// Esto se ejecuta cuando entras a la página para cargar lo que ya tenías guardado.
export async function GET() {
  try {
    // Buscamos la carta del Usuario 1 (El Coordinador/Admin por ahora)
    const carta = await prisma.cartaFrutos.findFirst({
      where: { usuarioId: 1 },
      orderBy: { id: 'desc' }, // Tomamos la más reciente
    });

    // Si no tiene carta, devolvemos un objeto vacío pero exitoso
    return NextResponse.json(carta || {});
  } catch (error) {
    return NextResponse.json({ error: 'Error cargando carta' }, { status: 500 });
  }
}

// 2. GUARDAR DATOS (POST)
// Esto se ejecuta cuando le das clic al botón "Guardar Progreso".
export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Usamos "upsert": Si existe, actualiza. Si no existe, crea una nueva.
    const cartaActualizada = await prisma.cartaFrutos.upsert({
      where: { 
        id: body.id || 0 // Si no hay ID, usamos 0 para forzar la creación
      },
      update: {
        finanzasMeta: body.FINANZAS?.meta,
        finanzasAvance: body.FINANZAS?.avance,
        finanzasScheduledDays: body.FINANZAS?.scheduledDays ? JSON.stringify(body.FINANZAS.scheduledDays) : null,
        relacionesMeta: body.RELACIONES?.meta,
        relacionesAvance: body.RELACIONES?.avance,
        relacionesScheduledDays: body.RELACIONES?.scheduledDays ? JSON.stringify(body.RELACIONES.scheduledDays) : null,
        talentosMeta: body.TALENTOS?.meta,
        talentosAvance: body.TALENTOS?.avance,
        talentosScheduledDays: body.TALENTOS?.scheduledDays ? JSON.stringify(body.TALENTOS.scheduledDays) : null,
        pazMentalMeta: body.PAZ_MENTAL?.meta,
        pazMentalAvance: body.PAZ_MENTAL?.avance,
        pazMentalScheduledDays: body.PAZ_MENTAL?.scheduledDays ? JSON.stringify(body.PAZ_MENTAL.scheduledDays) : null,
        ocioMeta: body.OCIO?.meta,
        ocioAvance: body.OCIO?.avance,
        ocioScheduledDays: body.OCIO?.scheduledDays ? JSON.stringify(body.OCIO.scheduledDays) : null,
        saludMeta: body.SALUD?.meta,
        saludAvance: body.SALUD?.avance,
        saludScheduledDays: body.SALUD?.scheduledDays ? JSON.stringify(body.SALUD.scheduledDays) : null,
        servicioComunMeta: body.COMUNIDAD?.meta,
        servicioComunAvance: body.COMUNIDAD?.avance,
        servicioComunScheduledDays: body.COMUNIDAD?.scheduledDays ? JSON.stringify(body.COMUNIDAD.scheduledDays) : null,
        enrolamientoMeta: body.ENROLAMIENTO?.meta,
        enrolamientoAvance: body.ENROLAMIENTO?.avance,
      },
      create: {
        usuarioId: 1,
        finanzasMeta: body.FINANZAS?.meta || "",
        finanzasAvance: body.FINANZAS?.avance || 0,
        finanzasScheduledDays: body.FINANZAS?.scheduledDays ? JSON.stringify(body.FINANZAS.scheduledDays) : null,
        relacionesMeta: body.RELACIONES?.meta || "",
        relacionesAvance: body.RELACIONES?.avance || 0,
        relacionesScheduledDays: body.RELACIONES?.scheduledDays ? JSON.stringify(body.RELACIONES.scheduledDays) : null,
        talentosMeta: body.TALENTOS?.meta || "",
        talentosAvance: body.TALENTOS?.avance || 0,
        talentosScheduledDays: body.TALENTOS?.scheduledDays ? JSON.stringify(body.TALENTOS.scheduledDays) : null,
        pazMentalMeta: body.PAZ_MENTAL?.meta || "",
        pazMentalAvance: body.PAZ_MENTAL?.avance || 0,
        pazMentalScheduledDays: body.PAZ_MENTAL?.scheduledDays ? JSON.stringify(body.PAZ_MENTAL.scheduledDays) : null,
        ocioMeta: body.OCIO?.meta || "",
        ocioAvance: body.OCIO?.avance || 0,
        ocioScheduledDays: body.OCIO?.scheduledDays ? JSON.stringify(body.OCIO.scheduledDays) : null,
        saludMeta: body.SALUD?.meta || "",
        saludAvance: body.SALUD?.avance || 0,
        saludScheduledDays: body.SALUD?.scheduledDays ? JSON.stringify(body.SALUD.scheduledDays) : null,
        servicioComunMeta: body.COMUNIDAD?.meta || "",
        servicioComunAvance: body.COMUNIDAD?.avance || 0,
        servicioComunScheduledDays: body.COMUNIDAD?.scheduledDays ? JSON.stringify(body.COMUNIDAD.scheduledDays) : null,
        enrolamientoMeta: body.ENROLAMIENTO?.meta || "Compromiso de enrolar 4 invitados.",
        enrolamientoAvance: body.ENROLAMIENTO?.avance || 0,
      },
    });

    return NextResponse.json(cartaActualizada);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Error guardando carta' }, { status: 500 });
  }
}