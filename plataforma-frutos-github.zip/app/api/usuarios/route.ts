import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET - Obtener todos los usuarios para el selector
export async function GET(request: NextRequest) {
  try {
    const usuarios = await prisma.usuario.findMany({
      where: { isActive: true },
      select: {
        id: true,
        nombre: true,
        email: true,
        vision: true
      },
      orderBy: { nombre: 'asc' }
    });

    return NextResponse.json(usuarios);

  } catch (error) {
    console.error('Error al obtener usuarios:', error);
    return NextResponse.json(
      { error: 'Error al obtener usuarios' },
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
