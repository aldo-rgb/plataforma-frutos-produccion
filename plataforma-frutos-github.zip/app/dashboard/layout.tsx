'use client';

import { useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { 
  LayoutDashboard, Trophy, Target, BarChart3, User, LogOut, 
  Menu, UserPlus, DollarSign, Package, Shield, 
  CreditCard, Gift, Lock, Compass, Bot, CheckCircle2
} from 'lucide-react';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  
  // --- 🛠 CONFIGURACIÓN DE PRUEBA (DESCOMENTA TU ROL) ---
  const USUARIO_PRUEBA = { nombre: 'Admin Master', rol: 'ADMIN', suscripcion: 'ACTIVO' };
  // const USUARIO_PRUEBA = { nombre: 'Coord. Juan', rol: 'COORDINADOR', suscripcion: 'INACTIVO' };
  // -------------------------------------------------------

  const [user, setUser] = useState<any>(USUARIO_PRUEBA); 
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // ROLES QUE NO PAGAN
  const ROLES_VIP = ['ADMIN', 'COORDINADOR', 'MENTOR', 'GAME_CHANGER'];

  useEffect(() => {
    const timer = setTimeout(() => {
      setUser(USUARIO_PRUEBA);
      setIsLoading(false);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  // CANDADO DE SEGURIDAD
  useEffect(() => {
    if (isLoading || !user) return;
    const esStaff = ROLES_VIP.includes(user.rol);
    const estaActivo = user.suscripcion === 'ACTIVO';

    if (!esStaff && !estaActivo && pathname !== '/dashboard/suscripcion') {
        router.push('/dashboard/suscripcion');
    }
  }, [user, pathname, isLoading, router]);

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    router.push('/'); 
  };

  if (isLoading) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-blue-500">Cargando...</div>;

  const isLocked = !ROLES_VIP.includes(user.rol) && user.suscripcion !== 'ACTIVO';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 flex">
      
      {/* SIDEBAR */}
      {!isLocked && (
        <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 transform transition-transform duration-300 md:relative md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex flex-col h-full">
            <div className="p-6 flex items-center gap-3 border-b border-slate-800">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center"><Target className="text-white" size={20} /></div>
              <span className="font-bold text-xl text-white tracking-wider">IMPACTO <span className="text-blue-500">VIA</span></span>
            </div>

            <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
              <Link href="/dashboard" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <LayoutDashboard size={20} /> <span>Dashboard</span>
              </Link>

              {/* --- LOS PERDIDOS (YA INCLUIDOS) --- */}
              <Link href="/dashboard/guia" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard/guia' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <Compass size={20} className="text-pink-500" /> <span>Guía de Inicio</span>
              </Link>
              <Link href="/dashboard/carta" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard/carta' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <Target size={20} className="text-purple-500" /> <span>Carta F.R.U.T.O.S.</span>
              </Link>
              <Link href="/dashboard/mentor-ia" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard/mentor-ia' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <Bot size={20} className="text-indigo-400" /> <span>Mentor IA</span>
              </Link>
              {/* ----------------------------------- */}

              <Link href="/dashboard/ranking" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard/ranking' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <Trophy size={20} /> <span>Ranking Global</span>
              </Link>
              <Link href="/dashboard/progreso" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard/progreso' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <BarChart3 size={20} /> <span>Análisis Progreso</span>
              </Link>
              <Link href="/dashboard/canjear" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard/canjear' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <Package size={20} /> <span>Tienda / Canje</span>
              </Link>
              <Link href="/dashboard/suscripcion" className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${pathname === '/dashboard/suscripcion' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <CreditCard size={20} /> <span>Membresía</span>
              </Link>

              {/* PANEL MAESTRO (ADMIN) */}
              {user?.rol === 'ADMIN' && (
                <div className="pt-6 mt-6 border-t border-slate-800">
                  <p className="px-4 text-xs font-bold text-slate-500 uppercase mb-2">Panel Maestro</p>
                  
                  {/* NOMBRE CORREGIDO: AUTORIZAR CARTAS */}
                  <Link href="/dashboard/staff" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
                    <Shield size={18} className="text-orange-500" /> <span>Autorizar Cartas</span>
                  </Link>
                  <Link href="/dashboard/admin/evidencias" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
                    <CheckCircle2 size={18} className="text-blue-500" /> <span>Autorizar Evidencias</span>
                  </Link>
                  <Link href="/dashboard/staff/alta-usuarios" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
                    <UserPlus size={18} /> <span>Alta Usuarios</span>
                  </Link>
                  <Link href="/dashboard/admin/pagos" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-emerald-900/20 transition-colors">
                    <DollarSign size={18} className="text-emerald-500" /> <span>Finanzas</span>
                  </Link>
                  <Link href="/dashboard/admin/productos" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-purple-900/20 transition-colors">
                    <Package size={18} className="text-purple-500" /> <span>Inv. Recompensas</span>
                  </Link>
                  <Link href="/dashboard/admin/precios" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
                    <Target size={18} /> <span>Gestión de Precios</span>
                  </Link>
                  <Link href="/dashboard/admin/usuarios" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
                    <User size={18} /> <span>Gestión Usuarios</span>
                  </Link>
                  <Link href="/dashboard/admin/codigos" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-yellow-900/20 transition-colors">
                    <Gift size={18} className="text-yellow-500" /> <span>Códigos de Regalo</span>
                  </Link>
                </div>
              )}
            </nav>

            <div className="p-4 border-t border-slate-800">
              <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-3 w-full rounded-lg text-red-400 hover:bg-red-900/20 transition-colors">
                <LogOut size={20} /> <span>Cerrar Sesión</span>
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* CONTENIDO */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-4 md:px-8 bg-slate-900/50 backdrop-blur-sm">
          <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="md:hidden text-slate-400 hover:text-white"><Menu size={24} /></button>
          <div className="ml-auto flex items-center gap-4">
            <div className="text-right">
                <h2 className="text-sm font-bold text-white">Hola, {user?.rol}</h2>
                <p className="text-[10px] text-slate-400 uppercase">{user?.nombre}</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">{user?.nombre?.charAt(0)}</div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto bg-slate-950 p-4 md:p-6 relative">
           {children}
        </main>
      </div>
    </div>
  );
}
