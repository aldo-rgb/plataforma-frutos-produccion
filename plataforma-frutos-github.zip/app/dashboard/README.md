Carpeta `app/dashboard`

Este directorio contendrá las páginas y componentes del Dashboard, que deben estar
protegidos y ser accesibles sólo después del login.

Recomendación:
- Implementar middleware o un wrapper de sesión para proteger `/dashboard`.
- Mantener aquí componentes y subrutas relacionadas con la experiencia privada.
