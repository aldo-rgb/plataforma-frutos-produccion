'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Zap, Trophy, Target, TrendingUp, CheckCircle, AlertCircle, CheckCircle2, Camera, Users, Flame, Medal, Crown } from 'lucide-react';

export default function DashboardHome() {
  // --- LÓGICA DE SALUDO DINÁMICO ---
  const [userRole, setUserRole] = useState('PARTICIPANTE');
  const [userName, setUserName] = useState('Líder');

  useEffect(() => {
    // Leer rol y nombre desde localStorage
    const rol = localStorage.getItem('userRol');
    const userId = localStorage.getItem('userId');
    
    if (rol) {
      setUserRole(rol);
    }
    
    // Si necesitas el nombre, puedes hacer una llamada a la API o guardarlo en localStorage al login
    // Por ahora usamos el rol para personalizar
  }, []);

  const getGreetingTitle = () => {
    if (userRole === 'ADMINISTRADOR') return `Hola, Administrador`;
    if (userRole === 'COORDINADOR') return `Hola, Coordinador`;
    if (userRole === 'MENTOR') return `Hola, Mentor`;
    if (userRole === 'GAMECHANGER') return `Hola, Game Changer`;
    return `Hola, Participante`;
  };

  const getGreetingMessage = () => {
    if (userRole === 'ADMINISTRADOR') return 'El panel de control maestro está listo.';
    if (userRole === 'COORDINADOR') return 'Tu equipo está esperando tu guía.';
    if (userRole === 'MENTOR') return 'Tus mentorados cuentan contigo.';
    return 'Esta semana tienes 2 metas críticas pendientes. Recuerda que la consistencia es la clave de la transformación cuántica.';
  };

  return (
    <div className="space-y-8">
      
      {/* 1. SECCIÓN DE BIENVENIDA / HERO */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-cyan-600 to-blue-700 p-8 shadow-2xl">
        <div className="absolute right-0 top-0 h-64 w-64 translate-x-1/3 -translate-y-1/2 rounded-full bg-white/10 blur-3xl"></div>
        <div className="relative z-10">
          <h1 className="text-3xl font-black text-white">{getGreetingTitle()}</h1>
          <p className="mt-2 max-w-xl text-cyan-100">
            {getGreetingMessage()}
          </p>
          <Link href="/dashboard/metas-hoy">
            <button className="mt-6 rounded-lg bg-white px-6 py-3 text-sm font-bold text-blue-700 shadow-lg transition-all hover:shadow-xl hover:scale-105">
              Ver mis Metas de Hoy
            </button>
          </Link>
        </div>
      </div>

      {/* --- KPIs INTERACTIVOS --- */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        
        {/* 1. PUNTOS CUÁNTICOS (Con Tooltip de Explicación) */}
        <div className="group relative bg-slate-900 p-6 rounded-xl border border-slate-800 hover:border-yellow-500/50 transition-all cursor-help overflow-hidden">
          {/* Contenido Visible */}
          <div className="relative z-10 group-hover:opacity-10 transition-opacity duration-300">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-yellow-500/10 rounded-lg text-yellow-500">
                <Zap size={24} />
              </div>
              <h3 className="text-slate-400 font-bold text-sm uppercase tracking-wider">Puntos Cuánticos</h3>
            </div>
            <p className="text-4xl font-bold text-white">4,850 <span className="text-lg text-slate-500 font-normal">PC</span></p>
          </div>

          {/* Capa de Explicación (DISEÑO MEJORADO) */}
          <div className="absolute inset-0 bg-slate-950/95 flex flex-col justify-center p-4 opacity-0 group-hover:opacity-100 transition-all duration-300 z-20 backdrop-blur-md">
            
            <div className="text-center mb-3">
              <p className="text-yellow-500 font-bold text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-2">
                <Zap size={14} /> Sistema de Recompensas
              </p>
            </div>
            
            <div className="space-y-2 w-full">
                {/* Item 1: Tarea */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-yellow-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                        <div className="p-1.5 rounded-md bg-blue-500/10 text-blue-400">
                           <CheckCircle2 size={16} />
                        </div>
                        <span className="text-slate-300 text-xs font-medium">Tarea Diaria</span>
                    </div>
                    <span className="text-yellow-400 font-bold text-sm bg-yellow-400/10 px-2 py-0.5 rounded">+10</span>
                </div>

                {/* Item 2: Evidencia */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-yellow-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                        <div className="p-1.5 rounded-md bg-purple-500/10 text-purple-400">
                           <Camera size={16} />
                        </div>
                        <span className="text-slate-300 text-xs font-medium">Evidencia Foto</span>
                    </div>
                    <span className="text-yellow-400 font-bold text-sm bg-yellow-400/10 px-2 py-0.5 rounded">+50</span>
                </div>

                {/* Item 3: Asistencia */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-yellow-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                        <div className="p-1.5 rounded-md bg-emerald-500/10 text-emerald-400">
                           <Users size={16} />
                        </div>
                        <span className="text-slate-300 text-xs font-medium">Asistencia Mentor</span>
                    </div>
                    <span className="text-yellow-400 font-bold text-sm bg-yellow-400/10 px-2 py-0.5 rounded">+100</span>
                </div>

                {/* Item 4: Racha */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-gradient-to-r from-orange-900/20 to-slate-900 border border-orange-500/20 hover:border-orange-500/50 transition-colors">
                    <div className="flex items-center gap-3">
                        <div className="p-1.5 rounded-md bg-orange-500/10 text-orange-500 animate-pulse">
                           <Flame size={16} />
                        </div>
                        <span className="text-orange-200 text-xs font-bold">Racha 7 Días</span>
                    </div>
                    <span className="text-orange-400 font-bold text-sm">+200</span>
                </div>
            </div>

            <p className="text-[10px] text-slate-500 text-center mt-3">
              *Los puntos se acreditan tras validación.
            </p>
          </div>
        </div>

        {/* 2. RANKING GLOBAL (PODIO INTERACTIVO) */}
        <div className="group relative bg-slate-900 p-6 rounded-xl border border-slate-800 hover:border-blue-500/50 transition-all cursor-help overflow-hidden">
          
          {/* Vista Normal (Tu posición actual) */}
          <div className="relative z-10 group-hover:opacity-10 transition-opacity duration-300">
             <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500">
                <Trophy size={24} />
              </div>
              <h3 className="text-slate-400 font-bold text-sm uppercase tracking-wider">Tu Posición</h3>
            </div>
            <p className="text-4xl font-bold text-white">#12 <span className="text-lg text-slate-500 font-normal">Global</span></p>
          </div>

           {/* Capa de Explicación: PODIO TOP 3 */}
           <div className="absolute inset-0 bg-slate-950/95 flex flex-col justify-center p-4 opacity-0 group-hover:opacity-100 transition-all duration-300 z-20 backdrop-blur-md">
            
            <div className="text-center mb-3">
              <p className="text-blue-400 font-bold text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-2">
                <Trophy size={14} /> Top 3 - Tu Visión
              </p>
            </div>

            <div className="space-y-2 w-full">
                
                {/* 🥇 1er LUGAR */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-gradient-to-r from-yellow-900/20 to-slate-900 border border-yellow-500/20">
                    <div className="flex items-center gap-3">
                        <div className="text-yellow-400">
                           <Crown size={18} />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-white text-xs font-bold">1. Ana Sofía</span>
                            <span className="text-[10px] text-yellow-500/80 font-bold">Líder Visionario</span>
                        </div>
                    </div>
                    <span className="text-white font-bold text-xs">5,200 PC</span>
                </div>

                {/* 🥈 2do LUGAR */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/80 border border-slate-700">
                    <div className="flex items-center gap-3">
                        <div className="text-slate-300">
                           <Medal size={18} />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-slate-200 text-xs font-medium">2. Roberto M.</span>
                        </div>
                    </div>
                    <span className="text-slate-400 font-bold text-xs">5,150 PC</span>
                </div>

                {/* 🥉 3er LUGAR */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/80 border border-slate-700">
                    <div className="flex items-center gap-3">
                        <div className="text-amber-600">
                           <Medal size={18} />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-slate-200 text-xs font-medium">3. Carlos R.</span>
                        </div>
                    </div>
                    <span className="text-slate-400 font-bold text-xs">4,980 PC</span>
                </div>

            </div>

            {/* Mensaje Motivacional al pie */}
            <div className="mt-3 text-center">
                <p className="text-[10px] text-slate-500">
                  Te faltan <span className="text-blue-400 font-bold">130 PC</span> para entrar al podio.
                </p>
            </div>
          </div>
        </div>

        {/* 3. META GLOBAL (Enlace Directo a Carta) */}
        <Link href="/dashboard/carta" className="block group">
          <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 hover:bg-slate-800/80 hover:border-purple-500/50 transition-all cursor-pointer h-full relative overflow-hidden">
            
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-purple-500/10 rounded-lg text-purple-500">
                <Target size={24} />
              </div>
              <h3 className="text-slate-400 font-bold text-sm uppercase tracking-wider">Meta Global</h3>
            </div>
            
            <div className="mt-2">
                <div className="flex justify-between items-end mb-1">
                    <span className="text-white font-bold text-xl">Progreso</span>
                    <span className="text-purple-400 text-sm font-bold">Ver Detalles &rarr;</span>
                </div>
                {/* Barra de progreso decorativa */}
                <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-purple-600 to-blue-500 w-[65%]"></div>
                </div>
                <p className="text-xs text-slate-500 mt-2">Haz clic para gestionar tus metas F.R.U.T.O.S.</p>
            </div>
          </div>
        </Link>

      </div>

      {/* 2. RESUMEN RÁPIDO (GRID) */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        
        {/* --- TARJETA CLICKEABLE: AVANCE GENERAL --- */}
        <Link href="/dashboard/progreso" className="block transition-transform hover:scale-[1.02] cursor-pointer">
          <div className="rounded-2xl border border-white/10 bg-slate-900/50 p-6 backdrop-blur-sm hover:border-cyan-500/50 transition-colors h-full">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-400">
                <TrendingUp size={24} />
              </div>
              <div>
                <p className="text-sm text-slate-400">Avance General F.R.U.T.O.S.</p>
                <p className="text-2xl font-bold text-white">42%</p>
              </div>
            </div>
            <div className="mt-4 h-2 w-full rounded-full bg-slate-800">
              <div className="h-full w-[42%] rounded-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.5)]"></div>
            </div>
          </div>
        </Link>

        {/* --- TARJETA CLICKEABLE: EVIDENCIAS / CARTA --- */}
        <Link href="/dashboard/carta" className="block transition-transform hover:scale-[1.02] cursor-pointer">
          <div className="rounded-2xl border border-white/10 bg-slate-900/50 p-6 backdrop-blur-sm hover:border-green-500/50 transition-colors h-full">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500/10 text-green-400">
                <CheckCircle size={24} />
              </div>
              <div>
                <p className="text-sm text-slate-400">Evidencias Semanales</p>
                <p className="text-2xl font-bold text-white">1 / 3</p>
              </div>
            </div>
            <p className="mt-4 text-xs text-green-400">
              +50 PC si completas 2 más esta semana.
            </p>
          </div>
        </Link>

        {/* --- TARJETA CLICKEABLE: CONTACTO / LLAMADAS --- */}
        <Link href="/dashboard/contacto" className="block transition-transform hover:scale-[1.02] cursor-pointer">
          <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-6 backdrop-blur-sm hover:border-red-500/50 transition-colors h-full">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-500/10 text-red-400">
                <AlertCircle size={24} />
              </div>
              <div>
                <p className="text-sm text-slate-400">Llamadas Perdidas</p>
                <p className="text-2xl font-bold text-white">0 <span className="text-base font-normal text-slate-500">/ 3</span></p>
              </div>
            </div>
            <p className="mt-4 text-xs text-red-400 font-semibold">
              Mantén tu integridad impecable.
            </p>
          </div>
        </Link>

      </div>
    </div>
  );
}