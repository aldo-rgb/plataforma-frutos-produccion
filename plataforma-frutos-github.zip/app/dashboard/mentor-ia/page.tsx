'use client';

import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, RefreshCcw, StopCircle, ArrowUp, Zap, Target, Heart } from 'lucide-react';

// TIPO DE MENSAJE
type Message = {
  id: number;
  role: 'user' | 'assistant';
  content: string;
};

export default function MentorIAPage() {
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // --- MENSAJES INICIALES ---
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      role: 'assistant',
      content: 'Hola, Líder. Soy tu Mentor Cuántico. Estoy conectado a tu visión y listo para desafiarte. ¿En qué trabajamos hoy?'
    }
  ]);

  // SCROLL AUTOMÁTICO
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // --- CEREBRO SIMULADO (MOCK) ---
  const generarRespuestaIA = (pregunta: string) => {
    const p = pregunta.toLowerCase();
    if (p.includes('miedo')) return "El miedo es emoción sin respiración. Respira profundo. ¿Qué harías ahora mismo si supieras que es imposible fallar?";
    if (p.includes('meta') || p.includes('objetivo')) return "Revisando tus metas... Veo que la intención es clara, pero falta acción masiva. ¿Cuál es el paso más pequeño e incómodo que puedes dar hoy?";
    if (p.includes('equipo')) return "Tu equipo es tu espejo. Si ellos están estancados, revisa tu propio movimiento. ¿Estás siendo la fuente de inspiración o solo estás gestionando tareas?";
    return "Esa es una distinción interesante. Profundicemos más: ¿Eso te acerca o te aleja de tu visión F.R.U.T.O.S.?";
  };

  // --- ENVIAR MENSAJE ---
  const handleSend = (texto: string = input) => {
    if (!texto.trim()) return;

    // 1. Usuario
    const userMsg: Message = { id: Date.now(), role: 'user', content: texto };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // 2. IA (Simulación)
    setTimeout(() => {
        const aiResponse: Message = {
            id: Date.now() + 1,
            role: 'assistant',
            content: generarRespuestaIA(texto)
        };
        setMessages(prev => [...prev, aiResponse]);
        setIsTyping(false);
    }, 1500);
  };

  // --- SUGERENCIAS RÁPIDAS (CHIPS) ---
  const sugerencias = [
      { icon: <Zap size={14}/>, text: "Necesito motivación hoy" },
      { icon: <Target size={14}/>, text: "Ayúdame con una meta" },
      { icon: <Heart size={14}/>, text: "Conflicto en relaciones" },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] max-w-4xl mx-auto relative">
      
      {/* --- HEADER SUTIL --- */}
      <div className="flex items-center justify-between px-6 py-4 bg-slate-950/80 backdrop-blur-sm sticky top-0 z-10 border-b border-white/5">
        <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Bot size={18} className="text-white" />
            </div>
            <div>
                <h1 className="font-bold text-white text-sm flex items-center gap-2">
                    Mentor IA <span className="px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] font-bold border border-indigo-500/20">V2.0</span>
                </h1>
            </div>
        </div>
        <button 
            onClick={() => setMessages([])} 
            className="p-2 text-slate-500 hover:text-white transition-colors"
            title="Limpiar chat"
        >
            <RefreshCcw size={16} />
        </button>
      </div>

      {/* --- ÁREA DE CHAT --- */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 custom-scrollbar">
        
        {/* ESTADO VACÍO (BIENVENIDA) */}
        {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-0 animate-in fade-in zoom-in duration-500">
                <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center mb-6 border border-slate-800">
                    <Sparkles size={40} className="text-indigo-500" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Hola, Líder</h3>
                <p className="text-slate-400 max-w-sm mb-8 text-sm">Soy tu inteligencia de soporte. ¿En qué nos enfocamos hoy?</p>
                
                <div className="flex flex-wrap justify-center gap-2 max-w-md">
                    {sugerencias.map((sug, idx) => (
                        <button 
                            key={idx}
                            onClick={() => handleSend(sug.text)}
                            className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 text-xs px-4 py-2 rounded-full transition-all"
                        >
                            {sug.icon} {sug.text}
                        </button>
                    ))}
                </div>
            </div>
        )}

        {/* MENSAJES */}
        {messages.map((msg) => (
            <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
                
                {/* Avatar IA */}
                {msg.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0 mt-1">
                        <Bot size={14} className="text-indigo-400" />
                    </div>
                )}

                {/* Burbuja */}
                <div className={`relative max-w-[80%] px-5 py-3 text-sm leading-relaxed shadow-sm ${
                    msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-2xl rounded-tr-sm' 
                    : 'bg-slate-800 text-slate-200 rounded-2xl rounded-tl-sm border border-slate-700'
                }`}>
                    {msg.content}
                </div>

                {/* Avatar Usuario (Opcional, se ve más limpio sin él a veces, pero lo dejo por simetría) */}
                {msg.role === 'user' && (
                    <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 mt-1">
                        <User size={14} className="text-slate-400" />
                    </div>
                )}
            </div>
        ))}

        {/* INDICADOR DE "ESCRIBIENDO..." */}
        {isTyping && (
            <div className="flex gap-3 justify-start animate-pulse">
                <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                    <Bot size={14} className="text-indigo-400" />
                </div>
                <div className="bg-slate-800 border border-slate-700 px-4 py-3 rounded-2xl rounded-tl-sm flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></div>
                </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* --- INPUT FLOTANTE (ESTILO MODERNO) --- */}
      <div className="p-4 pb-6">
        <form 
            onSubmit={(e) => { e.preventDefault(); handleSend(); }}
            className="relative flex items-end gap-2 bg-slate-900 border border-slate-700 rounded-3xl p-1.5 shadow-2xl focus-within:border-blue-500/50 focus-within:ring-1 focus-within:ring-blue-500/20 transition-all max-w-3xl mx-auto"
        >
            <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSend();
                    }
                }}
                placeholder="Escribe tu mensaje..."
                className="w-full bg-transparent text-white placeholder-slate-500 text-sm px-4 py-3 max-h-32 min-h-[44px] resize-none focus:outline-none custom-scrollbar"
                rows={1}
                disabled={isTyping}
            />
            
            <button 
                type="submit"
                disabled={!input.trim() || isTyping}
                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-all duration-200 mb-0.5 mr-0.5 ${
                    input.trim() && !isTyping
                    ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/30 scale-100' 
                    : 'bg-slate-800 text-slate-600 scale-95 cursor-not-allowed'
                }`}
            >
                {isTyping ? <StopCircle size={18} className="animate-pulse"/> : <ArrowUp size={20} strokeWidth={3} />}
            </button>
        </form>
        <p className="text-[10px] text-slate-600 text-center mt-3">
            Impacto Cuántico AI puede cometer errores. Verifica la info crítica.
        </p>
      </div>

    </div>
  );
}
