'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles } from 'lucide-react';

export default function ChatIAPage() {
  const [mensajes, setMensajes] = useState<{role: 'user'|'bot', text: string}[]>([
    { role: 'bot', text: 'Soy tu Mentor Cuántico con Inteligencia Artificial. ¿En qué área sientes resistencia hoy?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensajes]);

  const enviarMensaje = async () => {
    if (!input.trim()) return;
    
    const userText = input;
    setInput('');
    setMensajes(prev => [...prev, { role: 'user', text: userText }]);
    setLoading(true);

    try {
      const res = await fetch('/api/chat-ia', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mensaje: userText }),
      });
      const data = await res.json();
      
      if (res.ok && data.text) {
        setMensajes(prev => [...prev, { role: 'bot', text: data.text }]);
      } else {
        console.error('Error en respuesta:', data);
        setMensajes(prev => [...prev, { role: 'bot', text: data.error || 'El Quantum está recalibrando... intenta de nuevo.' }]);
      }
    } catch (error) {
      console.error('Error fetch:', error);
      setMensajes(prev => [...prev, { role: 'bot', text: 'Error de conexión con el núcleo.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-100px)] flex flex-col bg-slate-950 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
      
      {/* HEADER */}
      <div className="p-4 bg-slate-900 border-b border-white/10 flex items-center gap-4">
        <div className="relative">
            <div className="absolute inset-0 bg-purple-500 blur-lg opacity-50 animate-pulse"></div>
            <div className="relative h-12 w-12 bg-slate-950 rounded-full flex items-center justify-center border border-purple-500/50">
                <Sparkles className="text-purple-400" size={24} />
            </div>
        </div>
        <div>
            <h2 className="font-bold text-white text-lg">Mentor IA <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full ml-2">ONLINE</span></h2>
            <p className="text-xs text-slate-400">Inteligencia Artificial Generativa</p>
        </div>
      </div>

      {/* CHAT AREA */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {mensajes.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`
                    max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed shadow-lg
                    ${msg.role === 'user' 
                        ? 'bg-gradient-to-br from-cyan-600 to-blue-600 text-white rounded-tr-sm' 
                        : 'bg-slate-800 text-slate-200 border border-white/5 rounded-tl-sm'}
                `}>
                    {msg.text}
                </div>
            </div>
        ))}
        {loading && (
            <div className="flex justify-start">
                <div className="bg-slate-800 px-4 py-3 rounded-2xl flex gap-1 items-center">
                    <span className="text-xs text-slate-400 mr-2">Pensando</span>
                    <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce delay-100"></span>
                    <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce delay-200"></span>
                </div>
            </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* INPUT */}
      <div className="p-4 bg-slate-900 border-t border-white/10">
        <div className="flex gap-2">
            <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && enviarMensaje()}
                placeholder="Pregúntale algo a tu mentor..."
                className="flex-1 bg-slate-950 border border-white/10 rounded-xl px-4 text-white focus:outline-none focus:border-purple-500 transition-all"
            />
            <button 
                onClick={enviarMensaje}
                disabled={loading || !input}
                className="bg-purple-600 hover:bg-purple-500 text-white p-3 rounded-xl transition-all disabled:opacity-50"
            >
                <Send size={20} />
            </button>
        </div>
      </div>
    </div>
  );
}