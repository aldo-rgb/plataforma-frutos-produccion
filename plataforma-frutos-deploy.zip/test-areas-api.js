// Script de prueba para verificar el endpoint de áreas
console.log('Probando endpoint /api/areas-config...');

// Simular una solicitud como si fuera Usuario 6
// Este script es solo para debugging, no se ejecutará en producción
