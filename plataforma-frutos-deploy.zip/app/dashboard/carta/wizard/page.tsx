import CartaWizard from '@/components/dashboard/CartaWizard';

export default function WizardPage() {
  return <CartaWizard />;
}
