import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { emitToUser } from '@/lib/socket';

// PUT: Aprobar evidencia y otorgar puntos
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    }

    const evidenciaId = parseInt(params.id);

    if (isNaN(evidenciaId)) {
      return NextResponse.json({ error: 'ID de evidencia inválido' }, { status: 400 });
    }

    const mentor = await prisma.usuario.findUnique({
      where: { email: session.user.email },
    });

    if (!mentor) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Verificar permisos
    if (mentor.rol !== 'MENTOR' && mentor.rol !== 'COORDINADOR' && mentor.rol !== 'GAMECHANGER') {
      return NextResponse.json({ error: 'No tienes permisos de mentor' }, { status: 403 });
    }

    // Verificar que la evidencia existe
    const evidencia = await prisma.evidenciaAccion.findUnique({
      where: { id: evidenciaId },
      include: {
        Usuario: {
          select: {
            nombre: true,
            email: true,
            puntosGamificacion: true
          }
        }
      }
    });

    if (!evidencia) {
      return NextResponse.json({ error: 'Evidencia no encontrada' }, { status: 404 });
    }

    if (evidencia.estado !== 'PENDIENTE') {
      return NextResponse.json({ 
        error: `La evidencia ya fue revisada (Estado: ${evidencia.estado})` 
      }, { status: 400 });
    }

    // Puntos a otorgar
    const PUNTOS_POR_EVIDENCIA = 25;

    // Actualizar evidencia y puntos del usuario en una transacción
    const [evidenciaAprobada, usuarioActualizado] = await prisma.$transaction([
      prisma.evidenciaAccion.update({
        where: { id: evidenciaId },
        data: {
          estado: 'APROBADA',
          revisadoPorId: mentor.id,
          fechaRevision: new Date()
        }
      }),
      prisma.usuario.update({
        where: { id: evidencia.usuarioId },
        data: {
          puntosGamificacion: {
            increment: PUNTOS_POR_EVIDENCIA
          }
        }
      })
    ]);

    console.log(`✅ Evidencia ${evidenciaId} APROBADA por ${mentor.nombre}`);
    console.log(`   ${evidencia.Usuario.nombre} ganó +${PUNTOS_POR_EVIDENCIA} puntos (Total: ${usuarioActualizado.puntosGamificacion})`);

    // Enviar notificación en tiempo real
    try {
      emitToUser(evidencia.usuarioId.toString(), 'evidencia_aprobada', {
        evidenciaId: evidencia.id,
        mensaje: `¡Tu evidencia fue aprobada! Ganaste ${PUNTOS_POR_EVIDENCIA} puntos`,
        puntosGanados: PUNTOS_POR_EVIDENCIA,
        mentorNombre: mentor.nombre
      });
    } catch (socketError) {
      console.error('Error al enviar notificación Socket.IO:', socketError);
    }

    return NextResponse.json({ 
      success: true,
      message: `Evidencia aprobada. ${evidencia.Usuario.nombre} ganó ${PUNTOS_POR_EVIDENCIA} puntos.`,
      puntosOtorgados: PUNTOS_POR_EVIDENCIA,
      puntosToales: usuarioActualizado.puntosGamificacion
    }, { status: 200 });

  } catch (error) {
    console.error('❌ Error al aprobar evidencia:', error);
    return NextResponse.json({ error: 'Error al aprobar evidencia' }, { status: 500 });
  }
}
