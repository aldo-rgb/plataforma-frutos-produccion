import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

// GET: Obtener evidencias pendientes SOLO de usuarios asignados al mentor
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    }

    const mentor = await prisma.usuario.findUnique({
      where: { email: session.user.email },
    });

    if (!mentor) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Verificar permisos
    if (mentor.rol !== 'MENTOR' && mentor.rol !== 'COORDINADOR' && mentor.rol !== 'GAMECHANGER') {
      return NextResponse.json({ error: 'No tienes permisos de mentor' }, { status: 403 });
    }

    // FILTRO DE SEGURIDAD CRÍTICO: Solo evidencias de usuarios asignados a este mentor
    // Si es COORDINADOR o GAMECHANGER, puede ver todas las evidencias pendientes
    const esSupervisor = mentor.rol === 'COORDINADOR' || mentor.rol === 'GAMECHANGER';

    const whereClause = {
      estado: 'PENDIENTE' as const,
      ...(esSupervisor ? {} : {
        Usuario: {
          mentorId: mentor.id // FILTRO: Solo usuarios donde mentor_id = ID del mentor actual
        }
      })
    };

    // Obtener evidencias pendientes con filtro de seguridad
    const evidencias = await prisma.evidenciaAccion.findMany({
      where: whereClause,
      include: {
        Usuario: {
          select: {
            id: true,
            nombre: true,
            email: true,
            mentorId: true
          }
        },
        Accion: {
          select: {
            texto: true
          }
        },
        Meta: {
          select: {
            metaPrincipal: true,
            categoria: true
          }
        }
      },
      orderBy: {
        fechaSubida: 'desc'
      }
    });

    // Calcular tiempo relativo
    const getTiempoRelativo = (fecha: Date) => {
      const ahora = new Date();
      const diff = ahora.getTime() - fecha.getTime();
      const minutos = Math.floor(diff / 60000);
      const horas = Math.floor(minutos / 60);
      const dias = Math.floor(horas / 24);

      if (minutos < 1) return 'Hace un momento';
      if (minutos < 60) return `Hace ${minutos} min`;
      if (horas < 24) return `Hace ${horas}h`;
      if (dias === 1) return 'Hace 1 día';
      return `Hace ${dias} días`;
    };

    const evidenciasFormateadas = evidencias.map((ev: any) => ({
      id: ev.id,
      usuarioId: ev.usuarioId,
      usuarioNombre: ev.usuario.nombre,
      usuarioEmail: ev.usuario.email,
      metaTitulo: ev.meta?.metaPrincipal || 'Sin meta',
      categoria: ev.meta?.categoria || 'SIN_CATEGORIA',
      accionTexto: ev.accion.texto,
      fotoUrl: ev.fotoUrl,
      descripcion: ev.descripcion,
      fechaSubida: ev.fechaSubida,
      tiempoRelativo: getTiempoRelativo(new Date(ev.fechaSubida))
    }));

    console.log(`📋 Mentor ${mentor.nombre} consultó ${evidenciasFormateadas.length} evidencias pendientes`);

    return NextResponse.json({ 
      evidencias: evidenciasFormateadas,
      total: evidenciasFormateadas.length
    }, { status: 200 });

  } catch (error) {
    console.error('❌ Error al obtener evidencias para validación:', error);
    return NextResponse.json({ error: 'Error al cargar evidencias' }, { status: 500 });
  }
}
